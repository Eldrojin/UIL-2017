public class Abacus
{
    public static void main (String[] args)
    {
        System.out.println ("");
        System.out.println ("_________________________________________");
        System.out.println ("_________________________________________");
        System.out.println ("| |(_) (_) (_) (_) (_) (_) (_) (_) (_)| |");
        System.out.println ("| |_|___|___|___|___|___|___|___|___|_| |");
        System.out.println ("| | |   |   |   |   |   |   |   |   | | |");
        System.out.println ("| |(_) (_) (_) (_) (_) (_) (_) (_) (_)| |");
        System.out.println ("| |(_) (_) (_) (_) (_) (_) (_) (_) (_)| |");
        System.out.println ("| |(_) (_) (_) (_) (_) (_) (_) (_) (_)| |");
        System.out.println ("| |(_)_(_)_(_)_(_)_(_)_(_)_(_)_(_)_(_)| |");
        System.out.println ("_________________________________________");
	System.out.println ("");
    }
}

